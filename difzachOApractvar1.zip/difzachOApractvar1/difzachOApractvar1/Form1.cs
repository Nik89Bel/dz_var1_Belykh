﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace difzachOApractvar1
{
    public partial class Form1 : Form
    {
        private List<Country> countries;
        private List<Hotel> hotels;
        private List<dynamic> joinedData;
        public Form1()
        {
            InitializeComponent();
            countries = CountriesFromFile();
            hotels = HotelsFromFile();
            joinedData = JoinAndSort(countries, hotels, "Id").ToList();
            dataGridView1.DataSource = joinedData;
        }
        public IEnumerable<dynamic> JoinAndSort(List<Country> countries, List<Hotel> hotels, string sortBy)
        {
            var query = from country in countries
                        join hotel in hotels on country.Id equals hotel.Id
                        orderby Type.GetType(hotel.GetType().FullName).GetProperty(sortBy).GetValue(hotel, null)
                        select new { hotel.Id, hotel.HName, Country = country.CName, hotel.Price };
            return query.ToList();
        }
        public void RemoveRecord(List<dynamic> records, int id)
        {
            records.RemoveAll(r => r.Id == id);
        }
        private void УдалениеЭлементов(object sender, EventArgs e)
        {
            if (IdText.Text != "")
            {
                int id = int.Parse(IdText.Text);
                RemoveRecord(joinedData, id);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = joinedData;
            }
            else
                MessageBox.Show("Проверьте правильность ввода ID, для удаления", "Ошибка");
        }
        private List<Country> CountriesFromFile()
        {
            StreamReader sr = File.OpenText("f1.txt");
            var c1 = new List<Country>();
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split(',');
                c1.Add(new Country
                {
                    Id = int.Parse(line[0]),
                    CName = line[1]
                });
            }
            sr.Close();
            return c1;
        }
        private List<Hotel> HotelsFromFile()
        {
            StreamReader sr = File.OpenText("f2.txt");
            var h1 = new List<Hotel>();
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split(',');
                h1.Add(new Hotel
                {
                    Type = int.Parse(line[0]),
                    Id = int.Parse(line[1]),
                    HName = line[2],
                    Price = int.Parse(line[3])
               
                });
            }
            sr.Close();
            return h1;
        }
    }
}
