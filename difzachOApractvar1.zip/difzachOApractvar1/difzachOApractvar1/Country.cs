﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace difzachOApractvar1
{
    public class Country
    {
        public int Id { get; set; }
        public string CName { get; set; }
    }
}
